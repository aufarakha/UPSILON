su -c iptables --flush
